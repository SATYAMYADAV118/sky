package com.example.placementportal.service;

import java.util.List;

import com.example.placementportal.Student;

public interface IStudentService {

    public List<Student> getAllStudents();
    
    public Student getStudentById(long id);
    
    public void addStudent(Student student);
    
    public void updateStudent(Student student);
    
    public void deleteStudent(long id);
    
}
