package com.example.placementportal.service;

import java.util.List;

import com.example.placementportal.certificate;

public interface ICertificateService {

    public List<Certificate> getAllCertificates();
    
    public Certificate getCertificateById(long id);
    
    public void addCertificate(Certificate certificate);
    
    public void updateCertificate(Certificate certificate);
    
    public void deleteCertificate(long id);
    
}
