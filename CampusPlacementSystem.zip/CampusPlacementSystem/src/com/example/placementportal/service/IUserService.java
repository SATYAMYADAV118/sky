package com.example.placementportal.service;

import java.util.List;

import com.example.placementportal.User;

public interface IUserService {

    public List<User> getAllUsers();
    
    public User getUserById(long id);
    
    public void addUser(User user);
    
    public void updateUser(User user);
    
    public void deleteUser(long id);
    
}
