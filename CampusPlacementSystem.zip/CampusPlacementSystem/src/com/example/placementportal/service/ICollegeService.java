package com.example.placementportal.service;

import java.util.List;

import com.example.placementportal.College;

public interface ICollegeService {

    public List<College> getAllColleges();
    
    public College getCollegeById(long id);
    
    public void addCollege(College college);
    
    public void updateCollege(College college);
    
    public void deleteCollege(long id);
    
}
