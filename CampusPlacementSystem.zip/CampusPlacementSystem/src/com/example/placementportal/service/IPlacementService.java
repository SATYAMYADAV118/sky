package com.example.placementportal.service;

import java.util.List;

import com.example.placementportal.Placement;

public interface IPlacementService {

    public List<Placement> getAllPlacements();
    
    public Placement getPlacementById(long id);
    
    public void addPlacement(Placement placement);
    
    public void updatePlacement(Placement placement);
    
    public void deletePlacement(long id);
    
}
