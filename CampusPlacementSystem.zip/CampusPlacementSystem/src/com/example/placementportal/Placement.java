package com.example.placementportal;

import java.util.Date;

public class Placement {
    private long id;
    private Date date;
    private String qualification;
    private int year;
    private College college;
    
    // Constructors
    public Placement() {}
    
    public Placement(long id, Date date, String qualification, int year, College college) {
        this.id = id;
        this.date = date;
        this.qualification = qualification;
        this.year = year;
        this.college = college;
    }
    
    // Getters and Setters
    public long getId() {
        return id;
    }
    
    public void setId(long id) {
        this.id = id;
    }
    
    public Date getDate() {
        return date;
    }
    
    public void setDate(Date date) {
        this.date = date;
    }
    
    public String getQualification() {
        return qualification;
    }
    
    public void setQualification(String qualification) {
        this.qualification = qualification;
    }
    
    public int getYear() {
        return year;
    }
    
    public void setYear(int year) {
        this.year = year;
    }
    
    public College getCollege() {
        return college;
    }
    
    public void setCollege(College college) {
        this.college = college;
    }
}
