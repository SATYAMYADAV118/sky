package com.example.placementportal.repository;

import com.example.placementportal.certificate;

public interface ICertificateRepository {
    void addCertificate(certificate certificate);
    certificate getCertificateById(long id);
    void updateCertificate(certificate certificate);
    void deleteCertificateById(long id);
}
