package com.example.placementportal.repository;

import com.example.placementportal.User;

public interface IUserRepository {
    void addUser(User user);
    User getUserById(long id);
    void updateUser(User user);
    void deleteUserById(long id);
}
