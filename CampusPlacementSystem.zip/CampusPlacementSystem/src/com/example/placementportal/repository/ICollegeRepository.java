package com.example.placementportal.repository;

import com.example.placementportal.College;

public interface ICollegeRepository {
    void addCollege(College college);
    College getCollegeById(long id);
    void updateCollege(College college);
    void deleteCollegeById(long id);
}
