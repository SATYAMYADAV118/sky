package com.example.placementportal.repository;

import com.example.placementportal.Student;

public interface IStudentRepository {
    void addStudent(Student student);
    Student getStudentById(long id);
    void updateStudent(Student student);
    void deleteStudentById(long id);
}
