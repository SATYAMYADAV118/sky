package com.example.placementportal.repository;

import com.example.placementportal.Placement;

public interface IPlacementRepository {
    void addPlacement(Placement placement);
    Placement getPlacementById(long id);
    void updatePlacement(Placement placement);
    void deletePlacementById(long id);
}
