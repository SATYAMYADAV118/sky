package com.example.placementportal.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.placementportal.College;
import com.example.placementportal.service.ICollegeService;

@RestController
@RequestMapping("/colleges")
public class ICollegeController {
    
    @Autowired
    private ICollegeService collegeService;

    // Create a new college
    @PostMapping("/")
    public ResponseEntity<College> createCollege(@RequestBody College college) {
        College newCollege = collegeService.createCollege(college);
        return new ResponseEntity<College>(newCollege, HttpStatus.CREATED);
    }

    // Get all colleges
    @GetMapping("/")
    public ResponseEntity<List<College>> getAllColleges() {
        List<College> colleges = collegeService.getAllColleges();
        return new ResponseEntity<List<College>>(colleges, HttpStatus.OK);
    }

    // Get a specific college by ID
    @GetMapping("/{id}")
    public ResponseEntity<College> getCollegeById(@PathVariable("id") int id) {
        College college = collegeService.getCollegeById(id);
        return new ResponseEntity<College>(college, HttpStatus.OK);
    }

    // Update an existing college
    @PutMapping("/{id}")
    public ResponseEntity<College> updateCollege(@PathVariable("id") int id, @RequestBody College college) {
        College updatedCollege = collegeService.updateCollege(id, college);
        return new ResponseEntity<College>(updatedCollege, HttpStatus.OK);
    }

    // Delete a college by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCollege(@PathVariable("id") int id) {
        collegeService.deleteCollege(id);
        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }
}
