package com.example.placementportal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.placementportal.certificate;
import com.example.placementportal.service.ICertificateService;

@RestController
@RequestMapping("/certificates")
public class CertificateController {

    @Autowired
    private ICertificateService certificateService;

    // Create a new certificate
    @PostMapping("/")
    public ResponseEntity<certificate> createCertificate(@RequestBody certificate certificate) {
        certificate newcertificate = certificateService.createertificate(certificate);
        return new ResponseEntity<certificate>(newcertificate, HttpStatus.CREATED);
    }

    // Get all certificates
    @GetMapping("/")
    public ResponseEntity<List<certificate>> getAllcertificates() {
        List<certificate> certificates = certificateService.getAllcertificates();
        return new ResponseEntity<List<certificate>>(certificates, HttpStatus.OK);
    }

    // Get a specific certificate by ID
    @GetMapping("/{id}")
    public ResponseEntity<certificate> getCertificateById(@PathVariable("id") int id) {
        certificate certificate = certificateService.getcertificateById(id);
        return new ResponseEntity<certificate>(certificate, HttpStatus.OK);
    }

    // Update an existing certificate
    @PutMapping("/{id}")
    public ResponseEntity<certificate> updateCertificate(@PathVariable("id") int id, @RequestBody certificate certificate) {
        certificate updatedcertificate = certificateService.updatecertificate(id, certificate);
        return new ResponseEntity<certificate>(updatedcertificate, HttpStatus.OK);
    }

    // Delete a certificate by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCertificate(@PathVariable("id") int id) {
        certificateService.deleteCertificate(id);
        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }
}
