package com.example.placementportal.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.placementportal.Placement;
import com.example.placementportal.service.IPlacementService;

@RestController
@RequestMapping("/placements")
public class PlacementController {

    @Autowired
    private IPlacementService placementService;

    // Create a new placement
    @PostMapping("/")
    public ResponseEntity<Placement> createPlacement(@RequestBody Placement placement) {
        Placement newPlacement = placementService.createPlacement(placement);
        return new ResponseEntity<Placement>(newPlacement, HttpStatus.CREATED);
    }

    // Get all placements
    @GetMapping("/")
    public ResponseEntity<List<Placement>> getAllPlacements() {
        List<Placement> placements = placementService.getAllPlacements();
        return new ResponseEntity<List<Placement>>(placements, HttpStatus.OK);
    }

    // Get a specific placement by ID
    @GetMapping("/{id}")
    public ResponseEntity<Placement> getPlacementById(@PathVariable("id") int id) {
        Placement placement = placementService.getPlacementById(id);
        return new ResponseEntity<Placement>(placement, HttpStatus.OK);
    }

    // Update an existing placement
    @PutMapping("/{id}")
    public ResponseEntity<Placement> updatePlacement(@PathVariable("id") int id, @RequestBody Placement placement) {
        Placement updatedPlacement = placementService.updatePlacement(id, placement);
        return new ResponseEntity<Placement>(updatedPlacement, HttpStatus.OK);
    }

    // Delete a placement by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePlacement(@PathVariable("id") int id) {
        placementService.deletePlacement(id);
        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }
}
