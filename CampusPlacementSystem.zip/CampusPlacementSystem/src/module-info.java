module CampusPlacementSystem {
}